var routes = function(app, queue) {  
  app.post('/sphero/turn', function(req, res) {
  	try{
  		//Do sphero things with the request
  		queue.push({"message":"Turning!"});
		
		
  	} catch(ex){
  		res.status(500).json({error:"Something went wrong!", details:ex});
  		return;
  	}

    res.status(202).end();
  });

  app.post('/sphero/roll', function(req, res) {
  	try{
  		//Do sphero things with the request
  		queue.push({"message":"Rolling!"});
				
  	} catch(ex){
  		res.status(500).json({error:"Something went wrong!", details:ex});
  		return;
  	}	

    res.status(202).end();
  });

  app.post('/sphero/colour', function(req, res) {
  	try{
  		//Do sphero things with the request
		queue.push({"message":"Colouring???"});
		
  	} catch(ex){
  		res.status(500).json({error:"Something went wrong!", details:ex});
  		return;
  	}	

    res.status(202).send();
  });

};

module.exports = routes;  